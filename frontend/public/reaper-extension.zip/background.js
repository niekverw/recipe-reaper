// No background logic needed for this version
